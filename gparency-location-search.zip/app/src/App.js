import './App.css';
import SearchSuggestions from './components/SearchSuggestions';


function App() {
  return (
    <div id="searchApp">
      <SearchSuggestions />
    </div>
  );
}

export default App;
